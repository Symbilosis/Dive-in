package com.example.chatbot;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class MainActivity extends AppCompatActivity {
    RecyclerView recycle;
    TextView welcome;
    EditText message;
    ImageButton btn2;
    List<Message> messageList;
    MessageAdapter messageAdapter;
    public static final MediaType JSON = MediaType.get("application/json; charset=utf-8");
    OkHttpClient client = new OkHttpClient();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        messageList = new ArrayList<>();


        recycle =findViewById(R.id.recycle);
        welcome = findViewById(R.id.welcome);
        message = findViewById(R.id.message);
        btn2 = findViewById(R.id.btn2);

        //set recycler View
        messageAdapter = new MessageAdapter(messageList);
        recycle.setAdapter(messageAdapter);
        LinearLayoutManager llm = new LinearLayoutManager(this );
        llm.setStackFromEnd(true);
        recycle.setLayoutManager(llm);


        btn2.setOnClickListener((v)->{
            String question =message.getText().toString().trim();
            Toast.makeText(this,question,Toast.LENGTH_LONG).show();
            addToChat(question,Message.SENT_BY_ME);

            message.setText("");
            callAPI(question);
            welcome.setVisibility(View.GONE);

        });
    }
       void addToChat(String message,String sentBy){
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                messageList.add(new Message(message,sentBy));
                messageAdapter.notifyDataSetChanged();
                recycle.smoothScrollToPosition(messageAdapter.getItemCount());

            }
        });

       }

       void addResponse(String response){
        messageList.remove(messageList.size()-1);
        addToChat(response,Message.SENT_BY_BOT);
       }

       void callAPI(String question){

        //okhttp
           messageList.add(new Message("Typing....", Message.SENT_BY_BOT));

           JSONObject  jsonBody = new JSONObject();
           try {
               jsonBody.put("prompt", question);
               jsonBody.put("max_tokens",4000);
               jsonBody.put("temperature",0);
               jsonBody.put( "model","text-davinci-003");
           } catch (JSONException e) {
               e.printStackTrace();
           }
           RequestBody body = RequestBody.create(jsonBody.toString(),JSON);
           Request request = new Request.Builder()
                   .url("https://api.openai.com/v1/completions")
                   .header("Authorization","Bearer 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")
                   .post(body)
                   .build();

           client.newCall(request).enqueue(new Callback() {
               @Override
               public void onFailure(@NonNull Call call, @NonNull IOException e) {
                addResponse("failed to load response due to "+e.getMessage());
               }

               @Override
               public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                if (response.isSuccessful()){

                    try {
                        JSONObject jsonObject = new JSONObject(response.body().string());
                        JSONArray jsonArray = jsonObject.getJSONArray("choices");

                        String result = jsonArray.getJSONObject(0).getString("text");
                        addResponse(result.trim());


                    } catch (JSONException e) {
                        e.printStackTrace();
                    }


                }else{

                    addResponse("failed to load response due to "+response.body().string());
                }
               }
           });
       }
}